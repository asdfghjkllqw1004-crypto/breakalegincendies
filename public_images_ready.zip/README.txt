프로필 이미지 적용 방법

1. 이 압축파일을 풀면 public/images 폴더가 있습니다.
2. public 폴더를 performance-profile-site 프로젝트의 최상단에 넣어주세요.
   예: performance-profile-site/public/images/kim-seon-young.jpg
3. GitHub에 배포 중이라면 public 폴더도 함께 업로드해야 합니다.
4. Vercel에서 다시 Redeploy 하면 프로필 사진이 표시됩니다.

주의: 6번 사진은 요청대로 제외했습니다.
